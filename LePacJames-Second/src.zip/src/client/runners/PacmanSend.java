// package client.runners;
// import java.io.Serializable;

// public class PacmanSend implements Serializable {
//     public Integer x;
//     public Integer y;
//     public Integer angle;
//     private Integer id;

//     public PacmanSend(int x, int y, int angle, int id) {
//         this.x = x;
//         this.y = y;
//         this.angle = angle;
//         this.setId(id);
//     }

//     public Integer getId() {
//         return id;
//     }

//     public void setId(Integer id) {
//         this.id = id;
//     }

//     public Integer getX() {

//     }

//     public Integer

    

// }
