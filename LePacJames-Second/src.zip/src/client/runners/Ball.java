package client.runners;

/**
 * Class that represents a ball (eatable)
 * @author L. Krpan V.Schuster
 * @version 18/4/2022
 */

import javafx.geometry.Point2D;

public class Ball extends Runner {
    // private double startPos;
    // private double direction;
    // private final double padding = 2;

    private static final String IMG_PATH = "img/ball.png";

    public Ball(Point2D pos) {
        super(IMG_PATH, pos);
        this.pos = pos;
    }

    @Override
    public void update() {

    }

    @Override
    public boolean isMoving(double lastX, double lastY) {
        // TODO Auto-generated method stub
        return false;
    }

}