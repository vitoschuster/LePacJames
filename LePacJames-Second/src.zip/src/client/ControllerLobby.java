package client;

import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;
import static client.Constants.*;

public class ControllerLobby {

    @FXML
    Button btnReady;

    @FXML
    TextArea taReady;
    
    Stage stage;
    int numPlayers = -1;
    int readyCounter = -1;
     
    public void displayName(String name) {
        taReady.appendText(name + "\n");
        numPlayers++;
    }

    public int getNumPlayers() {
        return numPlayers;
    }

    public void switchToMultiplayer(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("../fxml/menumultiplayer.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root, W.toInt(), H.toInt()));
        stage.show();
    }

    public void play(ActionEvent event) throws Exception {
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        btnReady.setDisable(true);
        /** when other button is clicked */
    }
    

}
